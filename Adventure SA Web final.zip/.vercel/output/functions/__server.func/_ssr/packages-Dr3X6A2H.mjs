import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Shell } from "./site-DHb6Ueek.mjs";
import { t as ExperienceCard } from "./cards-Dg3hvuLy.mjs";
import { l as packages } from "./router-DrB_COnu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/packages-Dr3X6A2H.js
var import_jsx_runtime = require_jsx_runtime();
function PackagesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-5 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-5xl text-navy",
				children: "Packages"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-muted",
				children: "Four full experiences at R1 500 per person. Open a package for what is included, then add it to a quote with any activities."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-6 md:grid-cols-2",
				children: packages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceCard, { item }, item.slug))
			})
		]
	}) });
}
//#endregion
export { PackagesPage as component };
