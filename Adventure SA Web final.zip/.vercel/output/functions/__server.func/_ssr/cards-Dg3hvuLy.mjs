import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as formatRand } from "./router-DrB_COnu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/cards-Dg3hvuLy.js
var import_jsx_runtime = require_jsx_runtime();
function ExperienceCard({ item }) {
	const href = item.kind === "package" ? "/packages/$slug" : "/activities/$slug";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col overflow-hidden rounded-card bg-paper shadow-sm ring-1 ring-line",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: item.image,
			alt: "",
			className: "h-52 w-full object-cover"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-1 flex-col p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-widest text-forest",
					children: item.place
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "mt-2 text-2xl text-navy",
					children: item.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 flex-1 text-sm text-muted",
					children: item.blurb
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-end justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xl font-semibold text-forest",
						children: [formatRand(item.price), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block text-xs font-medium text-muted",
							children: "per person"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: href,
						params: { slug: item.slug },
						className: "rounded-full bg-navy px-4 py-2 text-sm font-semibold text-cream",
						children: "Details"
					})]
				})
			]
		})]
	});
}
//#endregion
export { ExperienceCard as t };
