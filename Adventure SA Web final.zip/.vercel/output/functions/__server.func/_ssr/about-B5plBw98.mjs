import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Shell } from "./site-DHb6Ueek.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-B5plBw98.js
var import_jsx_runtime = require_jsx_runtime();
function About() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 md:grid-cols-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
			src: "/photos/hike.jpg",
			alt: "Hikers on a forest trail",
			className: "h-full max-h-[520px] w-full rounded-card object-cover"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-semibold uppercase tracking-widest text-ember",
				children: "The client"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 text-5xl text-navy",
				children: "Built for people who would rather be outside."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-muted",
				children: "Liam Daniels started Adventure Escape SA in 2024 after watching families, schools and visiting groups bounce between operators just to book one decent day."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "The company runs professionally guided outdoor adventures across the Western Cape for every age and experience level. Teamwork, fitness and time in nature are the point — the website is only the first step."
			})
		] })]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
		className: "bg-paper",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-6xl gap-6 px-5 py-16 md:grid-cols-3",
			children: [
				["Vision", "The trusted first stop for outdoor days in the Western Cape."],
				["Mission", "Make discovery, comparison and quoting simple enough that the adventure stays the exciting part."],
				["Who it is for", "Individuals, families, schools, visitors and corporate teams."]
			].map(([title, copy]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-card border border-line p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-3xl text-navy",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: copy
				})]
			}, title))
		})
	})] });
}
//#endregion
export { About as component };
