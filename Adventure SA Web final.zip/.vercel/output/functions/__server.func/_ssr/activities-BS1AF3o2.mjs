import { S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Shell } from "./site-DHb6Ueek.mjs";
import { t as ExperienceCard } from "./cards-Dg3hvuLy.mjs";
import { a as activities } from "./router-DrB_COnu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/activities-BS1AF3o2.js
var import_jsx_runtime = require_jsx_runtime();
function ActivitiesPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-6xl px-5 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-5xl text-navy",
				children: "Activities"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 max-w-2xl text-muted",
				children: "Three shorter sessions at R750 per person. Book one on its own, or stack them with a package to unlock the discount."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-10 grid gap-6 md:grid-cols-3",
				children: activities.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceCard, { item }, item.slug))
			})
		]
	}) });
}
//#endregion
export { ActivitiesPage as component };
