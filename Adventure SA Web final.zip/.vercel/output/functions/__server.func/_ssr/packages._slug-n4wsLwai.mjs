import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Shell } from "./site-DHb6Ueek.mjs";
import { c as formatRand, l as packages, r as Route, s as findExperience } from "./router-DrB_COnu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/packages._slug-n4wsLwai.js
var import_jsx_runtime = require_jsx_runtime();
function PackageDetail() {
	const { slug } = Route.useParams();
	const item = packages.find((p) => p.slug === slug) ?? findExperience(slug);
	if (!item || item.kind !== "package") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-5 py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-4xl text-navy",
			children: "Package not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/packages",
			className: "mt-4 inline-block text-forest",
			children: "Back to packages"
		})]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, { itemSlug: item.slug });
}
function Detail({ itemSlug }) {
	const item = findExperience(itemSlug);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "relative h-80 bg-navy md:h-96",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: item.image,
				alt: "",
				className: "h-full w-full object-cover opacity-80"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-linear-to-t from-navy via-navy/30 to-transparent" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "absolute inset-x-0 bottom-0 mx-auto max-w-6xl px-5 pb-8 text-cream",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm uppercase tracking-widest text-ember",
					children: [
						item.place,
						" · ",
						item.duration
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 text-5xl",
					children: item.name
				})]
			})
		]
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto grid max-w-6xl gap-10 px-5 py-12 md:grid-cols-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:col-span-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-lg text-ink",
					children: item.story
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 text-3xl text-navy",
					children: "Included"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2 text-ink",
					children: item.includes.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "border-b border-line py-2",
						children: line
					}, line))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-8 text-3xl text-navy",
					children: "Who it suits"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-muted",
					children: item.who
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "h-fit rounded-card bg-navy p-6 text-cream",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-cream/70",
					children: "Fee"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-4xl text-ember",
					children: formatRand(item.price)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-cream/70",
					children: "per person, before multi-booking discount and VAT"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/quote",
					className: "mt-6 block rounded-full bg-ember px-4 py-3 text-center font-semibold text-paper",
					children: "Add to a quote"
				})
			]
		})]
	})] });
}
//#endregion
export { Detail, PackageDetail as component };
