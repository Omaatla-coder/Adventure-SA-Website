import { i as __toESM } from "../_runtime.mjs";
import { J as require_react, S as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Shell } from "./site-DHb6Ueek.mjs";
import { c as formatRand, o as experiences, u as quoteTotals } from "./router-DrB_COnu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/quote-Cm35bNC8.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function QuotePage() {
	const [name, setName] = (0, import_react.useState)("");
	const [email, setEmail] = (0, import_react.useState)("");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [selected, setSelected] = (0, import_react.useState)([]);
	const [show, setShow] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)("");
	const totals = (0, import_react.useMemo)(() => quoteTotals(selected), [selected]);
	function toggle(slug) {
		setSelected((current) => current.includes(slug) ? current.filter((s) => s !== slug) : [...current, slug]);
		setShow(false);
	}
	function onQuote() {
		if (!name.trim() || !email.includes("@")) {
			setError("Add your name and a real email so the quote can be sent back.");
			setShow(false);
			return;
		}
		if (selected.length === 0) {
			setError("Choose at least one package or activity.");
			setShow(false);
			return;
		}
		setError("");
		setShow(true);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-5 py-14",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-5xl text-navy",
				children: "Instant quote"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-muted",
				children: "Tick what you want. One booking is full price, two is 5% off, three is 10%, four or more is 15%. VAT of 15% is added after the discount. This is a quote, not an invoice."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "mt-8 space-y-4 rounded-card bg-paper p-6 ring-1 ring-line",
				onSubmit: (event) => {
					event.preventDefault();
					onQuote();
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Full name",
						value: name,
						onChange: setName,
						type: "text"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email",
						value: email,
						onChange: setEmail,
						type: "email"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Phone",
						value: phone,
						onChange: setPhone,
						type: "tel"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("legend", {
						className: "text-sm font-semibold text-navy",
						children: "Packages and activities"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid gap-2",
						children: experiences.map((item) => {
							const on = selected.includes(item.slug);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: `flex min-h-12 cursor-pointer items-center gap-3 rounded-2xl border px-4 py-3 ${on ? "border-forest bg-cream" : "border-line bg-paper"}`,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "checkbox",
										checked: on,
										onChange: () => toggle(item.slug),
										className: "size-5 accent-forest"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex-1 text-sm font-medium",
										children: item.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-sm text-forest",
										children: formatRand(item.price)
									})
								]
							}, item.slug);
						})
					})] }),
					error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-ember",
						children: error
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "submit",
						className: "w-full rounded-full bg-ember py-3 font-semibold text-paper",
						children: "Calculate quote"
					}),
					show && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card bg-navy p-5 text-cream",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-cream/70",
								children: [totals.count, " selected · stored as your selection list"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "Subtotal",
								value: formatRand(totals.subtotal)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: `Discount ${totals.discountPercent}%`,
								value: `− ${formatRand(Math.round(totals.discount))}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
								label: "VAT 15%",
								value: formatRand(Number(totals.vat.toFixed(2)))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-3 flex items-center justify-between border-t border-cream/20 pt-3 text-xl",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Quoted total" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-ember",
									children: formatRand(Number(totals.total.toFixed(2)))
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-sm text-cream/75",
								children: [
									"Thanks ",
									name.trim(),
									". We will use ",
									email.trim(),
									phone.trim() ? ` and ${phone.trim()}` : "",
									" to confirm dates. Not a tax invoice."
								]
							})
						]
					})
				]
			})
		]
	}) });
}
function Field({ label, value, onChange, type }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "block text-sm font-semibold text-navy",
		children: [label, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
			type,
			value,
			onChange: (event) => onChange(event.target.value),
			className: "mt-1 w-full rounded-xl border border-line bg-cream px-3 py-3 font-normal text-ink outline-none focus:border-ember"
		})]
	});
}
function Row({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-2 flex justify-between text-sm",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: value })]
	});
}
//#endregion
export { QuotePage as component };
