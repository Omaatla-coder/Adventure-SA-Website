import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Shell } from "./site-DHb6Ueek.mjs";
import { t as ExperienceCard } from "./cards-Dg3hvuLy.mjs";
import { a as activities, l as packages } from "./router-DrB_COnu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-ChnaZt7G.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Shell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "relative min-h-[78vh] bg-navy text-cream",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: "/photos/forest.jpg",
					alt: "Sunlit forest path in the mountains",
					className: "absolute inset-0 h-full w-full object-cover opacity-55"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "absolute inset-0 bg-navy/45" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "relative mx-auto flex min-h-[78vh] max-w-6xl flex-col justify-end px-5 pb-16 pt-28",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-semibold uppercase tracking-widest text-ember",
							children: "Western Cape · Est. 2024"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 max-w-3xl text-5xl text-cream md:text-7xl",
							children: "Discover. Explore. Escape."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-xl text-lg text-cream/90",
							children: "One place to compare guided outdoor days — families, schools, visitors and teams — then see the price before you enquire."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/packages",
								className: "rounded-full bg-ember px-5 py-3 font-semibold text-paper",
								children: "See packages"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/quote",
								className: "rounded-full border border-cream/50 px-5 py-3 font-semibold text-cream",
								children: "Calculate a quote"
							})]
						})
					]
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mx-auto max-w-6xl px-5 py-16",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-4xl text-navy",
					children: "Packages"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-muted",
					children: "Four guided days. Each is R1 500 per person."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/packages",
					className: "hidden text-sm font-semibold text-forest md:inline",
					children: "All packages"
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-6 md:grid-cols-2",
				children: packages.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceCard, { item }, item.slug))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "bg-paper py-16",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-4xl text-navy",
						children: "Add an activity"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-muted",
						children: "Ziplining, kayaking or climbing. Combine two or more bookings and the discount starts at 5%."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-8 grid gap-6 md:grid-cols-3",
						children: activities.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceCard, { item }, item.slug))
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "mx-auto grid max-w-6xl gap-6 px-5 py-16 md:grid-cols-3",
			children: [
				["More you book, more you save", "1 booking is full price. Two is 5% off, three is 10%, four or more is 15%, then 15% VAT."],
				["Guides stay with the group", "Every package and activity is led. Safety kit is part of the fee, not an extra."],
				["A quote, not an invoice", "The calculator shows a transparent total so you can decide before anyone calls you back."]
			].map(([title, copy]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-card bg-navy p-6 text-cream",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
					className: "text-2xl text-ember",
					children: title
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm text-cream/85",
					children: copy
				})]
			}, title))
		})
	] });
}
//#endregion
export { Home as component };
