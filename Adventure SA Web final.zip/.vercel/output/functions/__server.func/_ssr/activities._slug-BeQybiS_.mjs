import { S as require_jsx_runtime, b as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Shell } from "./site-DHb6Ueek.mjs";
import { a as activities, i as Route$1, n as Detail } from "./router-DrB_COnu.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/activities._slug-BeQybiS_.js
var import_jsx_runtime = require_jsx_runtime();
function ActivityDetail() {
	const { slug } = Route$1.useParams();
	const item = activities.find((a) => a.slug === slug);
	if (!item) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "mx-auto max-w-3xl px-5 py-20",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "text-4xl text-navy",
			children: "Activity not found"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/activities",
			className: "mt-4 inline-block text-forest",
			children: "Back to activities"
		})]
	}) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Detail, { itemSlug: item.slug });
}
//#endregion
export { ActivityDetail as component };
