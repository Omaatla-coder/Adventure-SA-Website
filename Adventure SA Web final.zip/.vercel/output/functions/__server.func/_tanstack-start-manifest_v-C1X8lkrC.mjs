//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-C1X8lkrC.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/activities",
			"/packages",
			"/quote"
		],
		preloads: [
			"/assets/index-CdaEfTrU.js",
			"/assets/site-AWkdeDyk.js",
			"/assets/packages._slug-B-FCk-j7.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CdaEfTrU.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-73ve8sqm.js",
			"/assets/experiences-w-hk42Mu.js",
			"/assets/cards-DcCo07Oq.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: ["/assets/about-CawxJZFr.js"]
	},
	"/activities": {
		filePath: "/workspace/src/routes/activities.tsx",
		children: ["/activities/$slug"],
		preloads: [
			"/assets/activities-C-inGKPM.js",
			"/assets/experiences-w-hk42Mu.js",
			"/assets/cards-DcCo07Oq.js"
		]
	},
	"/packages": {
		filePath: "/workspace/src/routes/packages.tsx",
		children: ["/packages/$slug"],
		preloads: [
			"/assets/packages-Up9FljYR.js",
			"/assets/experiences-w-hk42Mu.js",
			"/assets/cards-DcCo07Oq.js"
		]
	},
	"/quote": {
		filePath: "/workspace/src/routes/quote.tsx",
		children: void 0,
		preloads: ["/assets/quote-D7fq1f0f.js", "/assets/experiences-w-hk42Mu.js"]
	},
	"/activities/$slug": {
		filePath: "/workspace/src/routes/activities.$slug.tsx",
		children: void 0,
		preloads: ["/assets/activities._slug-B2v1Ozg-.js"]
	},
	"/packages/$slug": {
		filePath: "/workspace/src/routes/packages.$slug.tsx",
		children: void 0,
		preloads: ["/assets/packages._slug-DONopF3P.js"]
	}
} });
//#endregion
export { tsrStartManifest };
