import { createFileRoute, Link } from "@tanstack/react-router";
import { ExperienceCard } from "@/components/cards";
import { Shell } from "@/components/site";
import { activities, packages } from "@/data/experiences";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <Shell>
      <section className="relative min-h-[78vh] bg-navy text-cream">
        <img
          src="/photos/forest.jpg"
          alt="Sunlit forest path in the mountains"
          className="absolute inset-0 h-full w-full object-cover opacity-55"
        />
        <div className="absolute inset-0 bg-navy/45" />
        <div className="relative mx-auto flex min-h-[78vh] max-w-6xl flex-col justify-end px-5 pb-16 pt-28">
          <p className="text-sm font-semibold uppercase tracking-widest text-ember">Western Cape · Est. 2024</p>
          <h1 className="mt-3 max-w-3xl text-5xl text-cream md:text-7xl">
            Discover. Explore. Escape.
          </h1>
          <p className="mt-4 max-w-xl text-lg text-cream/90">
            One place to compare guided outdoor days — families, schools, visitors and teams — then see the price before you enquire.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link to="/packages" className="rounded-full bg-ember px-5 py-3 font-semibold text-paper">
              See packages
            </Link>
            <Link to="/quote" className="rounded-full border border-cream/50 px-5 py-3 font-semibold text-cream">
              Calculate a quote
            </Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-5 py-16">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <h2 className="text-4xl text-navy">Packages</h2>
            <p className="mt-2 text-muted">Four guided days. Each is R1 500 per person.</p>
          </div>
          <Link to="/packages" className="hidden text-sm font-semibold text-forest md:inline">
            All packages
          </Link>
        </div>
        <div className="grid gap-6 md:grid-cols-2">
          {packages.map((item) => (
            <ExperienceCard key={item.slug} item={item} />
          ))}
        </div>
      </section>

      <section className="bg-paper py-16">
        <div className="mx-auto max-w-6xl px-5">
          <h2 className="text-4xl text-navy">Add an activity</h2>
          <p className="mt-2 max-w-xl text-muted">
            Ziplining, kayaking or climbing. Combine two or more bookings and the discount starts at 5%.
          </p>
          <div className="mt-8 grid gap-6 md:grid-cols-3">
            {activities.map((item) => (
              <ExperienceCard key={item.slug} item={item} />
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-6 px-5 py-16 md:grid-cols-3">
        {[
          ["More you book, more you save", "1 booking is full price. Two is 5% off, three is 10%, four or more is 15%, then 15% VAT."],
          ["Guides stay with the group", "Every package and activity is led. Safety kit is part of the fee, not an extra."],
          ["A quote, not an invoice", "The calculator shows a transparent total so you can decide before anyone calls you back."],
        ].map(([title, copy]) => (
          <div key={title} className="rounded-card bg-navy p-6 text-cream">
            <h3 className="text-2xl text-ember">{title}</h3>
            <p className="mt-3 text-sm text-cream/85">{copy}</p>
          </div>
        ))}
      </section>
    </Shell>
  );
}
