import { createFileRoute, Link } from "@tanstack/react-router";
import { Shell } from "@/components/site";
import { findExperience, formatRand, packages } from "@/data/experiences";

export const Route = createFileRoute("/packages/$slug")({ component: PackageDetail });

function PackageDetail() {
  const { slug } = Route.useParams();
  const item = packages.find((p) => p.slug === slug) ?? findExperience(slug);
  if (!item || item.kind !== "package") {
    return (
      <Shell>
        <section className="mx-auto max-w-3xl px-5 py-20">
          <h1 className="text-4xl text-navy">Package not found</h1>
          <Link to="/packages" className="mt-4 inline-block text-forest">Back to packages</Link>
        </section>
      </Shell>
    );
  }
  return <Detail itemSlug={item.slug} />;
}

export function Detail({ itemSlug }: { itemSlug: string }) {
  const item = findExperience(itemSlug)!;
  return (
    <Shell>
      <section className="relative h-80 bg-navy md:h-96">
        <img src={item.image} alt="" className="h-full w-full object-cover opacity-80" />
        <div className="absolute inset-0 bg-linear-to-t from-navy via-navy/30 to-transparent" />
        <div className="absolute inset-x-0 bottom-0 mx-auto max-w-6xl px-5 pb-8 text-cream">
          <p className="text-sm uppercase tracking-widest text-ember">{item.place} · {item.duration}</p>
          <h1 className="mt-2 text-5xl">{item.name}</h1>
        </div>
      </section>
      <section className="mx-auto grid max-w-6xl gap-10 px-5 py-12 md:grid-cols-3">
        <div className="md:col-span-2">
          <p className="text-lg text-ink">{item.story}</p>
          <h2 className="mt-8 text-3xl text-navy">Included</h2>
          <ul className="mt-4 space-y-2 text-ink">
            {item.includes.map((line) => (
              <li key={line} className="border-b border-line py-2">{line}</li>
            ))}
          </ul>
          <h2 className="mt-8 text-3xl text-navy">Who it suits</h2>
          <p className="mt-3 text-muted">{item.who}</p>
        </div>
        <aside className="h-fit rounded-card bg-navy p-6 text-cream">
          <p className="text-sm text-cream/70">Fee</p>
          <p className="text-4xl text-ember">{formatRand(item.price)}</p>
          <p className="text-sm text-cream/70">per person, before multi-booking discount and VAT</p>
          <Link to="/quote" className="mt-6 block rounded-full bg-ember px-4 py-3 text-center font-semibold text-paper">
            Add to a quote
          </Link>
        </aside>
      </section>
    </Shell>
  );
}
