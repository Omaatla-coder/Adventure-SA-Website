import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Shell } from "@/components/site";
import { experiences, formatRand, quoteTotals } from "@/data/experiences";

export const Route = createFileRoute("/quote")({ component: QuotePage });

function QuotePage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [selected, setSelected] = useState<string[]>([]);
  const [show, setShow] = useState(false);
  const [error, setError] = useState("");

  const totals = useMemo(() => quoteTotals(selected), [selected]);

  function toggle(slug: string) {
    setSelected((current) =>
      current.includes(slug) ? current.filter((s) => s !== slug) : [...current, slug],
    );
    setShow(false);
  }

  function onQuote() {
    if (!name.trim() || !email.includes("@")) {
      setError("Add your name and a real email so the quote can be sent back.");
      setShow(false);
      return;
    }
    if (selected.length === 0) {
      setError("Choose at least one package or activity.");
      setShow(false);
      return;
    }
    setError("");
    setShow(true);
  }

  return (
    <Shell>
      <section className="mx-auto max-w-3xl px-5 py-14">
        <h1 className="text-5xl text-navy">Instant quote</h1>
        <p className="mt-3 text-muted">
          Tick what you want. One booking is full price, two is 5% off, three is 10%, four or more is 15%. VAT of 15% is added after the discount. This is a quote, not an invoice.
        </p>

        <form
          className="mt-8 space-y-4 rounded-card bg-paper p-6 ring-1 ring-line"
          onSubmit={(event) => {
            event.preventDefault();
            onQuote();
          }}
        >
          <Field label="Full name" value={name} onChange={setName} type="text" />
          <Field label="Email" value={email} onChange={setEmail} type="email" />
          <Field label="Phone" value={phone} onChange={setPhone} type="tel" />

          <fieldset>
            <legend className="text-sm font-semibold text-navy">Packages and activities</legend>
            <div className="mt-3 grid gap-2">
              {experiences.map((item) => {
                const on = selected.includes(item.slug);
                return (
                  <label
                    key={item.slug}
                    className={`flex min-h-12 cursor-pointer items-center gap-3 rounded-2xl border px-4 py-3 ${on ? "border-forest bg-cream" : "border-line bg-paper"}`}
                  >
                    <input
                      type="checkbox"
                      checked={on}
                      onChange={() => toggle(item.slug)}
                      className="size-5 accent-forest"
                    />
                    <span className="flex-1 text-sm font-medium">{item.name}</span>
                    <span className="text-sm text-forest">{formatRand(item.price)}</span>
                  </label>
                );
              })}
            </div>
          </fieldset>

          {error && <p className="text-sm font-medium text-ember">{error}</p>}

          <button type="submit" className="w-full rounded-full bg-ember py-3 font-semibold text-paper">
            Calculate quote
          </button>

          {show && (
            <div className="rounded-card bg-navy p-5 text-cream">
              <p className="text-sm text-cream/70">{totals.count} selected · stored as your selection list</p>
              <Row label="Subtotal" value={formatRand(totals.subtotal)} />
              <Row label={`Discount ${totals.discountPercent}%`} value={`− ${formatRand(Math.round(totals.discount))}`} />
              <Row label="VAT 15%" value={formatRand(Number(totals.vat.toFixed(2)))} />
              <div className="mt-3 flex items-center justify-between border-t border-cream/20 pt-3 text-xl">
                <span>Quoted total</span>
                <span className="text-ember">{formatRand(Number(totals.total.toFixed(2)))}</span>
              </div>
              <p className="mt-3 text-sm text-cream/75">
                Thanks {name.trim()}. We will use {email.trim()}
                {phone.trim() ? ` and ${phone.trim()}` : ""} to confirm dates. Not a tax invoice.
              </p>
            </div>
          )}
        </form>
      </section>
    </Shell>
  );
}

function Field({
  label,
  value,
  onChange,
  type,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
  type: string;
}) {
  return (
    <label className="block text-sm font-semibold text-navy">
      {label}
      <input
        type={type}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="mt-1 w-full rounded-xl border border-line bg-cream px-3 py-3 font-normal text-ink outline-none focus:border-ember"
      />
    </label>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="mt-2 flex justify-between text-sm">
      <span>{label}</span>
      <span>{value}</span>
    </div>
  );
}
