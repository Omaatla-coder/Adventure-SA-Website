import { createFileRoute, Link } from "@tanstack/react-router";
import { Detail } from "./packages.$slug";
import { Shell } from "@/components/site";
import { activities } from "@/data/experiences";

export const Route = createFileRoute("/activities/$slug")({ component: ActivityDetail });

function ActivityDetail() {
  const { slug } = Route.useParams();
  const item = activities.find((a) => a.slug === slug);
  if (!item) {
    return (
      <Shell>
        <section className="mx-auto max-w-3xl px-5 py-20">
          <h1 className="text-4xl text-navy">Activity not found</h1>
          <Link to="/activities" className="mt-4 inline-block text-forest">Back to activities</Link>
        </section>
      </Shell>
    );
  }
  return <Detail itemSlug={item.slug} />;
}
