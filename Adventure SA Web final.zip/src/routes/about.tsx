import { createFileRoute } from "@tanstack/react-router";
import { Shell } from "@/components/site";

export const Route = createFileRoute("/about")({ component: About });

function About() {
  return (
    <Shell>
      <section className="mx-auto grid max-w-6xl items-center gap-10 px-5 py-16 md:grid-cols-2">
        <img
          src="/photos/hike.jpg"
          alt="Hikers on a forest trail"
          className="h-full max-h-[520px] w-full rounded-card object-cover"
        />
        <div>
          <p className="text-sm font-semibold uppercase tracking-widest text-ember">The client</p>
          <h1 className="mt-2 text-5xl text-navy">Built for people who would rather be outside.</h1>
          <p className="mt-4 text-muted">
            Liam Daniels started Adventure Escape SA in 2024 after watching families, schools and visiting groups bounce between operators just to book one decent day.
          </p>
          <p className="mt-3 text-muted">
            The company runs professionally guided outdoor adventures across the Western Cape for every age and experience level. Teamwork, fitness and time in nature are the point — the website is only the first step.
          </p>
        </div>
      </section>
      <section className="bg-paper">
        <div className="mx-auto grid max-w-6xl gap-6 px-5 py-16 md:grid-cols-3">
          {[
            ["Vision", "The trusted first stop for outdoor days in the Western Cape."],
            ["Mission", "Make discovery, comparison and quoting simple enough that the adventure stays the exciting part."],
            ["Who it is for", "Individuals, families, schools, visitors and corporate teams."],
          ].map(([title, copy]) => (
            <article key={title} className="rounded-card border border-line p-6">
              <h2 className="text-3xl text-navy">{title}</h2>
              <p className="mt-3 text-muted">{copy}</p>
            </article>
          ))}
        </div>
      </section>
    </Shell>
  );
}
