import { createFileRoute } from "@tanstack/react-router";
import { ExperienceCard } from "@/components/cards";
import { Shell } from "@/components/site";
import { activities } from "@/data/experiences";

export const Route = createFileRoute("/activities")({ component: ActivitiesPage });

function ActivitiesPage() {
  return (
    <Shell>
      <section className="mx-auto max-w-6xl px-5 py-14">
        <h1 className="text-5xl text-navy">Activities</h1>
        <p className="mt-3 max-w-2xl text-muted">
          Three shorter sessions at R750 per person. Book one on its own, or stack them with a package to unlock the discount.
        </p>
        <div className="mt-10 grid gap-6 md:grid-cols-3">
          {activities.map((item) => (
            <ExperienceCard key={item.slug} item={item} />
          ))}
        </div>
      </section>
    </Shell>
  );
}
