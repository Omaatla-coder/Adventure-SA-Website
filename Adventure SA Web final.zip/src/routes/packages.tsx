import { createFileRoute } from "@tanstack/react-router";
import { ExperienceCard } from "@/components/cards";
import { Shell } from "@/components/site";
import { packages } from "@/data/experiences";

export const Route = createFileRoute("/packages")({ component: PackagesPage });

function PackagesPage() {
  return (
    <Shell>
      <section className="mx-auto max-w-6xl px-5 py-14">
        <h1 className="text-5xl text-navy">Packages</h1>
        <p className="mt-3 max-w-2xl text-muted">
          Four full experiences at R1 500 per person. Open a package for what is included, then add it to a quote with any activities.
        </p>
        <div className="mt-10 grid gap-6 md:grid-cols-2">
          {packages.map((item) => (
            <ExperienceCard key={item.slug} item={item} />
          ))}
        </div>
      </section>
    </Shell>
  );
}
