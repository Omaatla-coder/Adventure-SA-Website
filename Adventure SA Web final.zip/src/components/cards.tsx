import { Link } from "@tanstack/react-router";
import { formatRand, type Experience } from "@/data/experiences";

export function ExperienceCard({ item }: { item: Experience }) {
  const href = item.kind === "package" ? "/packages/$slug" : "/activities/$slug";
  return (
    <article className="flex flex-col overflow-hidden rounded-card bg-paper shadow-sm ring-1 ring-line">
      <img src={item.image} alt="" className="h-52 w-full object-cover" />
      <div className="flex flex-1 flex-col p-5">
        <p className="text-xs font-semibold uppercase tracking-widest text-forest">{item.place}</p>
        <h3 className="mt-2 text-2xl text-navy">{item.name}</h3>
        <p className="mt-2 flex-1 text-sm text-muted">{item.blurb}</p>
        <div className="mt-4 flex items-end justify-between gap-3">
          <p className="text-xl font-semibold text-forest">
            {formatRand(item.price)}
            <span className="block text-xs font-medium text-muted">per person</span>
          </p>
          <Link
            to={href}
            params={{ slug: item.slug }}
            className="rounded-full bg-navy px-4 py-2 text-sm font-semibold text-cream"
          >
            Details
          </Link>
        </div>
      </div>
    </article>
  );
}
