import type { ReactNode } from "react";
import { Link, useRouterState } from "@tanstack/react-router";
import { Menu, X } from "lucide-react";
import { useState } from "react";

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link to="/" className="flex items-center gap-3">
      <svg viewBox="0 0 64 64" className="size-11 shrink-0" aria-hidden="true">
        <circle cx="32" cy="32" r="30" fill={light ? "#FFF6DC" : "#0A2540"} />
        <path d="M10 44 L22 24 L32 34 L43 18 L54 44 Z" fill={light ? "#0A2540" : "#FFF6DC"} />
        <path d="M10 44 L24 30 L32 38 L42 26 L54 44 Z" fill="#1F6B2C" />
        <circle cx="44" cy="16" r="6" fill="#E85D04" />
        <path d="M22 50 Q32 42 42 50" stroke="#E85D04" strokeWidth="2.4" fill="none" strokeLinecap="round" />
      </svg>
      <span className={`font-display text-lg leading-none ${light ? "text-cream" : "text-navy"}`}>
        Adventure Escape
        <span className="block text-sm tracking-wide text-ember">South Africa</span>
      </span>
    </Link>
  );
}

const links = [
  { to: "/", label: "Home" },
  { to: "/about", label: "About" },
  { to: "/packages", label: "Packages" },
  { to: "/activities", label: "Activities" },
] as const;

export function Header() {
  const [open, setOpen] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });

  return (
    <header className="sticky top-0 z-40 border-b border-line bg-navy text-cream">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-5 py-3">
        <Logo light />
        <nav className="hidden items-center gap-7 md:flex">
          {links.map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className={`text-sm font-medium ${path === link.to ? "text-ember" : "text-cream/90 hover:text-ember"}`}
            >
              {link.label}
            </Link>
          ))}
          <Link to="/quote" className="rounded-full bg-ember px-4 py-2 text-sm font-semibold text-paper">
            Get a quote
          </Link>
        </nav>
        <button
          type="button"
          className="grid size-11 place-items-center rounded-full border border-cream/30 md:hidden"
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X /> : <Menu />}
        </button>
      </div>
      {open && (
        <nav className="flex flex-col gap-1 border-t border-cream/15 px-5 py-3 md:hidden">
          {links.map((link) => (
            <Link key={link.to} to={link.to} onClick={() => setOpen(false)} className="py-3 text-base">
              {link.label}
            </Link>
          ))}
          <Link to="/quote" onClick={() => setOpen(false)} className="mt-1 rounded-full bg-ember px-4 py-3 text-center font-semibold text-paper">
            Get a quote
          </Link>
        </nav>
      )}
    </header>
  );
}

export function Footer() {
  return (
    <footer className="bg-navy text-cream">
      <div className="mx-auto grid max-w-6xl gap-8 px-5 py-12 md:grid-cols-4">
        <div className="md:col-span-2">
          <Logo light />
          <p className="mt-4 max-w-sm text-sm text-cream/80">
            Professionally guided outdoor adventures across the Western Cape. Compare, select, and get a clear quote before you book.
          </p>
        </div>
        <div className="text-sm">
          <p className="font-semibold text-paper">Visit</p>
          <p className="mt-2 text-cream/80">Western Cape, South Africa</p>
          <p className="text-cream/80">Founded by Liam Daniels, 2024</p>
        </div>
        <div className="text-sm">
          <p className="font-semibold text-paper">Contact</p>
          <p className="mt-2 text-cream/80">hello@adventureescapesa.co.za</p>
          <p className="text-cream/80">+27 21 555 0199</p>
        </div>
      </div>
      <p className="border-t border-cream/15 px-5 py-4 text-center text-xs text-cream/60">
        Discover. Explore. Escape.
      </p>
    </footer>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col">
      <Header />
      <main className="flex-1">{children}</main>
      <Footer />
    </div>
  );
}
